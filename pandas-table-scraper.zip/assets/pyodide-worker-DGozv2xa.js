var Se = (e, t) => () => (t || e((t = { exports: {} }).exports, t), t.exports);
var Te = Se((Ce, T) => {
  var Oe = Object.defineProperty, o = (e, t) => Oe(e, "name", { value: t, configurable: !0 }), j = ((e) => typeof require < "u" ? require : typeof Proxy < "u" ? new Proxy(e, { get: (t, r) => (typeof require < "u" ? require : t)[r] }) : e)(function(e) {
    if (typeof require < "u") return require.apply(this, arguments);
    throw Error('Dynamic require of "' + e + '" is not supported');
  }), _e = (() => {
    for (var e = new Uint8Array(128), t = 0; t < 64; t++) e[t < 26 ? t + 65 : t < 52 ? t + 71 : t < 62 ? t - 4 : t * 4 - 205] = t;
    return (r) => {
      for (var a = r.length, n = new Uint8Array((a - (r[a - 1] == "=") - (r[a - 2] == "=")) * 3 / 4 | 0), i = 0, s = 0; i < a; ) {
        var l = e[r.charCodeAt(i++)], c = e[r.charCodeAt(i++)], u = e[r.charCodeAt(i++)], d = e[r.charCodeAt(i++)];
        n[s++] = l << 2 | c >> 4, n[s++] = c << 4 | u >> 2, n[s++] = u << 6 | d;
      }
      return n;
    };
  })();
  function B(e) {
    return !isNaN(parseFloat(e)) && isFinite(e);
  }
  o(B, "_isNumber");
  function g(e) {
    return e.charAt(0).toUpperCase() + e.substring(1);
  }
  o(g, "_capitalize");
  function F(e) {
    return function() {
      return this[e];
    };
  }
  o(F, "_getter");
  var N = ["isConstructor", "isEval", "isNative", "isToplevel"], I = ["columnNumber", "lineNumber"], S = ["fileName", "functionName", "source"], Ae = ["args"], Re = ["evalOrigin"], P = N.concat(I, S, Ae, Re);
  function m(e) {
    if (e) for (var t = 0; t < P.length; t++) e[P[t]] !== void 0 && this["set" + g(P[t])](e[P[t]]);
  }
  o(m, "StackFrame");
  m.prototype = { getArgs: o(function() {
    return this.args;
  }, "getArgs"), setArgs: o(function(e) {
    if (Object.prototype.toString.call(e) !== "[object Array]") throw new TypeError("Args must be an Array");
    this.args = e;
  }, "setArgs"), getEvalOrigin: o(function() {
    return this.evalOrigin;
  }, "getEvalOrigin"), setEvalOrigin: o(function(e) {
    if (e instanceof m) this.evalOrigin = e;
    else if (e instanceof Object) this.evalOrigin = new m(e);
    else throw new TypeError("Eval Origin must be an Object or StackFrame");
  }, "setEvalOrigin"), toString: o(function() {
    var e = this.getFileName() || "", t = this.getLineNumber() || "", r = this.getColumnNumber() || "", a = this.getFunctionName() || "";
    return this.getIsEval() ? e ? "[eval] (" + e + ":" + t + ":" + r + ")" : "[eval]:" + t + ":" + r : a ? a + " (" + e + ":" + t + ":" + r + ")" : e + ":" + t + ":" + r;
  }, "toString") };
  m.fromString = o(function(e) {
    var t = e.indexOf("("), r = e.lastIndexOf(")"), a = e.substring(0, t), n = e.substring(t + 1, r).split(","), i = e.substring(r + 1);
    if (i.indexOf("@") === 0) var s = /@(.+?)(?::(\d+))?(?::(\d+))?$/.exec(i, ""), l = s[1], c = s[2], u = s[3];
    return new m({ functionName: a, args: n || void 0, fileName: l, lineNumber: c || void 0, columnNumber: u || void 0 });
  }, "StackFrame$$fromString");
  for (w = 0; w < N.length; w++) m.prototype["get" + g(N[w])] = F(N[w]), m.prototype["set" + g(N[w])] = /* @__PURE__ */ (function(e) {
    return function(t) {
      this[e] = !!t;
    };
  })(N[w]);
  var w;
  for (E = 0; E < I.length; E++) m.prototype["get" + g(I[E])] = F(I[E]), m.prototype["set" + g(I[E])] = /* @__PURE__ */ (function(e) {
    return function(t) {
      if (!B(t)) throw new TypeError(e + " must be a Number");
      this[e] = Number(t);
    };
  })(I[E]);
  var E;
  for (v = 0; v < S.length; v++) m.prototype["get" + g(S[v])] = F(S[v]), m.prototype["set" + g(S[v])] = /* @__PURE__ */ (function(e) {
    return function(t) {
      this[e] = String(t);
    };
  })(S[v]);
  var v, D = m;
  function H() {
    var e = /^\s*at .*(\S+:\d+|\(native\))/m, t = /^(eval@)?(\[native code])?$/;
    return { parse: o(function(r) {
      if (r.stack && r.stack.match(e)) return this.parseV8OrIE(r);
      if (r.stack) return this.parseFFOrSafari(r);
      throw new Error("Cannot parse given Error object");
    }, "ErrorStackParser$$parse"), extractLocation: o(function(r) {
      if (r.indexOf(":") === -1) return [r];
      var a = /(.+?)(?::(\d+))?(?::(\d+))?$/, n = a.exec(r.replace(/[()]/g, ""));
      return [n[1], n[2] || void 0, n[3] || void 0];
    }, "ErrorStackParser$$extractLocation"), parseV8OrIE: o(function(r) {
      var a = r.stack.split(`
`).filter(function(n) {
        return !!n.match(e);
      }, this);
      return a.map(function(n) {
        n.indexOf("(eval ") > -1 && (n = n.replace(/eval code/g, "eval").replace(/(\(eval at [^()]*)|(,.*$)/g, ""));
        var i = n.replace(/^\s+/, "").replace(/\(eval code/g, "(").replace(/^.*?\s+/, ""), s = i.match(/ (\(.+\)$)/);
        i = s ? i.replace(s[0], "") : i;
        var l = this.extractLocation(s ? s[1] : i), c = s && i || void 0, u = ["eval", "<anonymous>"].indexOf(l[0]) > -1 ? void 0 : l[0];
        return new D({ functionName: c, fileName: u, lineNumber: l[1], columnNumber: l[2], source: n });
      }, this);
    }, "ErrorStackParser$$parseV8OrIE"), parseFFOrSafari: o(function(r) {
      var a = r.stack.split(`
`).filter(function(n) {
        return !n.match(t);
      }, this);
      return a.map(function(n) {
        if (n.indexOf(" > eval") > -1 && (n = n.replace(/ line (\d+)(?: > eval line \d+)* > eval:\d+:\d+/g, ":$1")), n.indexOf("@") === -1 && n.indexOf(":") === -1) return new D({ functionName: n });
        var i = /((.*".+"[^@]*)?[^@]*)(?:@)/, s = n.match(i), l = s && s[1] ? s[1] : void 0, c = this.extractLocation(n.replace(i, ""));
        return new D({ functionName: l, fileName: c[0], lineNumber: c[1], columnNumber: c[2], source: n });
      }, this);
    }, "ErrorStackParser$$parseFFOrSafari") };
  }
  o(H, "ErrorStackParser");
  var ke = new H(), Pe = ke;
  function z() {
    if (typeof API < "u" && API !== globalThis.API) return API.runtimeEnv;
    let e = typeof Bun < "u", t = typeof Deno < "u", r = typeof process == "object" && typeof process.versions == "object" && typeof process.versions.node == "string" && !process.browser, a = typeof navigator == "object" && typeof navigator.userAgent == "string" && navigator.userAgent.indexOf("Chrome") === -1 && navigator.userAgent.indexOf("Safari") > -1;
    return V({ IN_BUN: e, IN_DENO: t, IN_NODE: r, IN_SAFARI: a, IN_SHELL: typeof read == "function" && typeof load == "function" });
  }
  o(z, "getGlobalRuntimeEnv");
  var f = z();
  function V(e) {
    let t = e.IN_NODE && typeof T < "u" && T.exports && typeof j == "function" && typeof __dirname == "string", r = e.IN_NODE && !t, a = !e.IN_NODE && !e.IN_DENO && !e.IN_BUN, n = a && typeof window < "u" && typeof window.document < "u" && typeof document.createElement == "function" && "sessionStorage" in window && typeof globalThis.importScripts != "function", i = a && typeof globalThis.WorkerGlobalScope < "u" && typeof globalThis.self < "u" && globalThis.self instanceof globalThis.WorkerGlobalScope;
    return { ...e, IN_BROWSER: a, IN_BROWSER_MAIN_THREAD: n, IN_BROWSER_WEB_WORKER: i, IN_NODE_COMMONJS: t, IN_NODE_ESM: r };
  }
  o(V, "calculateDerivedFlags");
  var q, L, J, W, U;
  async function C() {
    if (!f.IN_NODE || (q = (await import("./__vite-browser-external-CPvbk0mb.js")).default, W = await import("./__vite-browser-external-CPvbk0mb.js"), U = await import("./__vite-browser-external-CPvbk0mb.js"), J = (await import("./__vite-browser-external-CPvbk0mb.js")).default, L = await import("./__vite-browser-external-CPvbk0mb.js"), M = L.sep, typeof j < "u")) return;
    let e = W, t = await import("./__vite-browser-external-CPvbk0mb.js"), r = await import("./__vite-browser-external-CPvbk0mb.js"), a = await import("./__vite-browser-external-CPvbk0mb.js"), n = { fs: e, crypto: t, ws: r, child_process: a };
    globalThis.require = function(i) {
      return n[i];
    };
  }
  o(C, "initNodeModules");
  function G(e, t) {
    return L.resolve(t || ".", e);
  }
  o(G, "node_resolvePath");
  function K(e, t) {
    return t === void 0 && (t = location), new URL(e, t).toString();
  }
  o(K, "browser_resolvePath");
  var R;
  f.IN_NODE ? R = G : f.IN_SHELL ? R = o((e) => e, "resolvePath") : R = K;
  var M;
  f.IN_NODE || (M = "/");
  function Y(e, t) {
    return e.startsWith("file://") && (e = e.slice(7)), e.includes("://") ? { response: fetch(e) } : { binary: U.readFile(e).then((r) => new Uint8Array(r.buffer, r.byteOffset, r.byteLength)) };
  }
  o(Y, "node_getBinaryResponse");
  function Z(e, t) {
    if (e.startsWith("file://") && (e = e.slice(7)), e.includes("://")) throw new Error("Shell cannot fetch urls");
    return { binary: Promise.resolve(new Uint8Array(readbuffer(e))) };
  }
  o(Z, "shell_getBinaryResponse");
  function Q(e, t) {
    let r = new URL(e, location);
    return { response: fetch(r, t ? { integrity: t } : {}) };
  }
  o(Q, "browser_getBinaryResponse");
  var k;
  f.IN_NODE ? k = Y : f.IN_SHELL ? k = Z : k = Q;
  async function X(e, t) {
    let { response: r, binary: a } = k(e, t);
    if (a) return a;
    let n = await r;
    if (!n.ok) throw new Error(`Failed to load '${e}': request failed.`);
    return new Uint8Array(await n.arrayBuffer());
  }
  o(X, "loadBinaryFile");
  var _;
  if (f.IN_BROWSER_MAIN_THREAD) _ = o(async (e) => await import(e), "loadScript");
  else if (f.IN_BROWSER_WEB_WORKER) _ = o(async (e) => {
    try {
      globalThis.importScripts(e);
    } catch (t) {
      if (t instanceof TypeError) await import(e);
      else throw t;
    }
  }, "loadScript");
  else if (f.IN_NODE) _ = ee;
  else if (f.IN_SHELL) _ = load;
  else throw new Error("Cannot determine runtime environment");
  async function ee(e) {
    e.startsWith("file://") && (e = e.slice(7)), e.includes("://") ? J.runInThisContext(await (await fetch(e)).text()) : await import(q.pathToFileURL(e).href);
  }
  o(ee, "nodeLoadScript");
  async function te(e) {
    if (f.IN_NODE) {
      await C();
      let t = await U.readFile(e, { encoding: "utf8" });
      return JSON.parse(t);
    } else if (f.IN_SHELL) {
      let t = read(e);
      return JSON.parse(t);
    } else return await (await fetch(e)).json();
  }
  o(te, "loadLockFile");
  async function re() {
    if (f.IN_NODE_COMMONJS) return __dirname;
    let e;
    try {
      throw new Error();
    } catch (a) {
      e = a;
    }
    let t = Pe.parse(e)[0].fileName;
    if (f.IN_NODE && !t.startsWith("file://") && (t = `file://${t}`), f.IN_NODE_ESM) {
      let a = await import("./__vite-browser-external-CPvbk0mb.js");
      return (await import("./__vite-browser-external-CPvbk0mb.js")).fileURLToPath(a.dirname(t));
    }
    let r = t.lastIndexOf(M);
    if (r === -1) throw new Error("Could not extract indexURL path from pyodide module location. Please pass the indexURL explicitly to loadPyodide.");
    return t.slice(0, r);
  }
  o(re, "calculateDirname");
  function ne(e) {
    return e.substring(0, e.lastIndexOf("/") + 1) || globalThis.location?.toString() || ".";
  }
  o(ne, "calculateInstallBaseUrl");
  function ie(e) {
    let t = e.FS, r = e.FS.filesystems.MEMFS, a = e.PATH, n = { DIR_MODE: 16895, FILE_MODE: 33279, mount: o(function(i) {
      if (!i.opts.fileSystemHandle) throw new Error("opts.fileSystemHandle is required");
      return r.mount.apply(null, arguments);
    }, "mount"), syncfs: o(async (i, s, l) => {
      try {
        let c = n.getLocalSet(i), u = await n.getRemoteSet(i), d = s ? u : c, y = s ? c : u;
        await n.reconcile(i, d, y), l(null);
      } catch (c) {
        l(c);
      }
    }, "syncfs"), getLocalSet: o((i) => {
      let s = /* @__PURE__ */ Object.create(null);
      function l(d) {
        return d !== "." && d !== "..";
      }
      o(l, "isRealDir");
      function c(d) {
        return (y) => a.join2(d, y);
      }
      o(c, "toAbsolute");
      let u = t.readdir(i.mountpoint).filter(l).map(c(i.mountpoint));
      for (; u.length; ) {
        let d = u.pop(), y = t.stat(d);
        t.isDir(y.mode) && u.push.apply(u, t.readdir(d).filter(l).map(c(d))), s[d] = { timestamp: y.mtime, mode: y.mode };
      }
      return { type: "local", entries: s };
    }, "getLocalSet"), getRemoteSet: o(async (i) => {
      let s = /* @__PURE__ */ Object.create(null), l = await Fe(i.opts.fileSystemHandle);
      for (let [c, u] of l) c !== "." && (s[a.join2(i.mountpoint, c)] = { timestamp: u.kind === "file" ? new Date((await u.getFile()).lastModified) : /* @__PURE__ */ new Date(), mode: u.kind === "file" ? n.FILE_MODE : n.DIR_MODE });
      return { type: "remote", entries: s, handles: l };
    }, "getRemoteSet"), loadLocalEntry: o((i) => {
      let s = t.lookupPath(i, {}).node, l = t.stat(i);
      if (t.isDir(l.mode)) return { timestamp: l.mtime, mode: l.mode };
      if (t.isFile(l.mode)) return s.contents = r.getFileDataAsTypedArray(s), { timestamp: l.mtime, mode: l.mode, contents: s.contents };
      throw new Error("node type not supported");
    }, "loadLocalEntry"), storeLocalEntry: o((i, s) => {
      if (t.isDir(s.mode)) t.mkdirTree(i, s.mode);
      else if (t.isFile(s.mode)) t.writeFile(i, s.contents, { canOwn: !0 });
      else throw new Error("node type not supported");
      t.chmod(i, s.mode), t.utime(i, s.timestamp, s.timestamp);
    }, "storeLocalEntry"), removeLocalEntry: o((i) => {
      var s = t.stat(i);
      t.isDir(s.mode) ? t.rmdir(i) : t.isFile(s.mode) && t.unlink(i);
    }, "removeLocalEntry"), loadRemoteEntry: o(async (i) => {
      if (i.kind === "file") {
        let s = await i.getFile();
        return { contents: new Uint8Array(await s.arrayBuffer()), mode: n.FILE_MODE, timestamp: new Date(s.lastModified) };
      } else {
        if (i.kind === "directory") return { mode: n.DIR_MODE, timestamp: /* @__PURE__ */ new Date() };
        throw new Error("unknown kind: " + i.kind);
      }
    }, "loadRemoteEntry"), storeRemoteEntry: o(async (i, s, l) => {
      let c = i.get(a.dirname(s)), u = t.isFile(l.mode) ? await c.getFileHandle(a.basename(s), { create: !0 }) : await c.getDirectoryHandle(a.basename(s), { create: !0 });
      if (u.kind === "file") {
        let d = await u.createWritable();
        await d.write(l.contents), await d.close();
      }
      i.set(s, u);
    }, "storeRemoteEntry"), removeRemoteEntry: o(async (i, s) => {
      await i.get(a.dirname(s)).removeEntry(a.basename(s)), i.delete(s);
    }, "removeRemoteEntry"), reconcile: o(async (i, s, l) => {
      let c = 0, u = [];
      Object.keys(s.entries).forEach(function(p) {
        let h = s.entries[p], b = l.entries[p];
        (!b || t.isFile(h.mode) && h.timestamp.getTime() > b.timestamp.getTime()) && (u.push(p), c++);
      }), u.sort();
      let d = [];
      if (Object.keys(l.entries).forEach(function(p) {
        s.entries[p] || (d.push(p), c++);
      }), d.sort().reverse(), !c) return;
      let y = s.type === "remote" ? s.handles : l.handles;
      for (let p of u) {
        let h = a.normalize(p.replace(i.mountpoint, "/")).substring(1);
        if (l.type === "local") {
          let b = y.get(h), Ie = await n.loadRemoteEntry(b);
          n.storeLocalEntry(p, Ie);
        } else {
          let b = n.loadLocalEntry(p);
          await n.storeRemoteEntry(y, h, b);
        }
      }
      for (let p of d) if (l.type === "local") n.removeLocalEntry(p);
      else {
        let h = a.normalize(p.replace(i.mountpoint, "/")).substring(1);
        await n.removeRemoteEntry(y, h);
      }
    }, "reconcile") };
    e.FS.filesystems.NATIVEFS_ASYNC = n;
  }
  o(ie, "initializeNativeFS");
  var Fe = o(async (e) => {
    let t = [];
    async function r(n) {
      for await (let i of n.values()) t.push(i), i.kind === "directory" && await r(i);
    }
    o(r, "collect"), await r(e);
    let a = /* @__PURE__ */ new Map();
    a.set(".", e);
    for (let n of t) {
      let i = (await e.resolve(n)).join("/");
      a.set(i, n);
    }
    return a;
  }, "getFsHandles"), De = _e("AGFzbQEAAAABDANfAGAAAW9gAW8BfwMDAgECByECD2NyZWF0ZV9zZW50aW5lbAAAC2lzX3NlbnRpbmVsAAEKEwIHAPsBAPsbCwkAIAD7GvsUAAs="), Le = (async function() {
    if (!(globalThis.navigator && (/iPad|iPhone|iPod/.test(navigator.userAgent) || navigator.platform === "MacIntel" && typeof navigator.maxTouchPoints < "u" && navigator.maxTouchPoints > 1))) try {
      let e = await WebAssembly.compile(De);
      return await WebAssembly.instantiate(e);
    } catch (e) {
      if (e instanceof WebAssembly.CompileError) return;
      throw e;
    }
  })();
  async function ae() {
    let e = await Le;
    if (e) return e.exports;
    let t = /* @__PURE__ */ Symbol("error marker");
    return { create_sentinel: o(() => t, "create_sentinel"), is_sentinel: o((r) => r === t, "is_sentinel") };
  }
  o(ae, "getSentinelImport");
  function oe(e) {
    let t = { config: e, runtimeEnv: f }, r = { noImageDecoding: !0, noAudioDecoding: !0, noWasmDecoding: !1, preRun: fe(e), print: e.stdout, printErr: e.stderr, onExit(a) {
      r.exitCode = a;
    }, thisProgram: e._sysExecutable, arguments: e.args, API: t, locateFile: o((a) => e.indexURL + a, "locateFile"), instantiateWasm: pe(e.indexURL) };
    return r;
  }
  o(oe, "createSettings");
  function se(e) {
    return function(t) {
      let r = "/";
      try {
        t.FS.mkdirTree(e);
      } catch (a) {
        console.error(`Error occurred while making a home directory '${e}':`), console.error(a), console.error(`Using '${r}' for a home directory instead`), e = r;
      }
      t.FS.chdir(e);
    };
  }
  o(se, "createHomeDirectory");
  function le(e) {
    return function(t) {
      Object.assign(t.ENV, e);
    };
  }
  o(le, "setEnvironment");
  function ce(e) {
    return e ? [async (t) => {
      t.addRunDependency("fsInitHook");
      try {
        await e(t.FS, { sitePackages: t.API.sitePackages });
      } finally {
        t.removeRunDependency("fsInitHook");
      }
    }] : [];
  }
  o(ce, "callFsInitHook");
  function ue(e) {
    let t = e.HEAPU32[e._Py_Version >>> 2], r = t >>> 24 & 255, a = t >>> 16 & 255, n = t >>> 8 & 255;
    return [r, a, n];
  }
  o(ue, "computeVersionTuple");
  function de(e) {
    let t = X(e);
    return async (r) => {
      r.API.pyVersionTuple = ue(r);
      let [a, n] = r.API.pyVersionTuple;
      r.FS.mkdirTree("/lib"), r.API.sitePackages = `/lib/python${a}.${n}/site-packages`, r.FS.mkdirTree(r.API.sitePackages), r.addRunDependency("install-stdlib");
      try {
        let i = await t;
        r.FS.writeFile(`/lib/python${a}${n}.zip`, i);
      } catch (i) {
        console.error("Error occurred while installing the standard library:"), console.error(i);
      } finally {
        r.removeRunDependency("install-stdlib");
      }
    };
  }
  o(de, "installStdlib");
  function fe(e) {
    let t;
    return e.stdLibURL != null ? t = e.stdLibURL : t = e.indexURL + "python_stdlib.zip", [de(t), se(e.env.HOME), le(e.env), ie, ...ce(e.fsInit)];
  }
  o(fe, "getFileSystemInitializationFuncs");
  function pe(e) {
    if (typeof WasmOffsetConverter < "u") return;
    let { binary: t, response: r } = k(e + "pyodide.asm.wasm"), a = ae();
    return function(n, i) {
      return (async function() {
        n.sentinel = await a;
        try {
          let s;
          r ? s = await WebAssembly.instantiateStreaming(r, n) : s = await WebAssembly.instantiate(await t, n);
          let { instance: l, module: c } = s;
          i(l, c);
        } catch (s) {
          console.warn("wasm instantiation failed!"), console.warn(s);
        }
      })(), {};
    };
  }
  o(pe, "getInstantiateWasmFunc");
  var xe = "0.29.0";
  function A(e) {
    return e === void 0 || e.endsWith("/") ? e : e + "/";
  }
  o(A, "withTrailingSlash");
  var x = xe;
  async function me(e = {}) {
    if (await C(), e.lockFileContents && e.lockFileURL) throw new Error("Can't pass both lockFileContents and lockFileURL");
    let t = e.indexURL || await re();
    if (t = A(R(t)), e.packageBaseUrl = A(e.packageBaseUrl), e.cdnUrl = A(e.packageBaseUrl ?? `https://cdn.jsdelivr.net/pyodide/v${x}/full/`), !e.lockFileContents) {
      let n = e.lockFileURL ?? t + "pyodide-lock.json";
      e.lockFileContents = te(n), e.packageBaseUrl ??= ne(n);
    }
    e.indexURL = t, e.packageCacheDir && (e.packageCacheDir = A(R(e.packageCacheDir)));
    let r = { fullStdLib: !1, jsglobals: globalThis, stdin: globalThis.prompt ? () => globalThis.prompt() : void 0, args: [], env: {}, packages: [], packageCacheDir: e.packageBaseUrl, enableRunUntilComplete: !0, checkAPIVersion: !0, BUILD_ID: "761936574707325565bed16f46bb59050f9a5477dab28ba3db09f3fb41ea89e7" }, a = Object.assign(r, e);
    return a.env.HOME ??= "/home/pyodide", a.env.PYTHONINSPECT ??= "1", a;
  }
  o(me, "initializeConfiguration");
  function ye(e) {
    let t = oe(e), r = t.API;
    return r.lockFilePromise = Promise.resolve(e.lockFileContents), t;
  }
  o(ye, "createEmscriptenSettings");
  async function ge(e) {
    if (typeof _createPyodideModule != "function") {
      let t = `${e.indexURL}pyodide.asm.js`;
      await _(t);
    }
  }
  o(ge, "loadWasmScript");
  async function he(e, t) {
    if (!e._loadSnapshot) return;
    let r = await e._loadSnapshot, a = ArrayBuffer.isView(r) ? r : new Uint8Array(r);
    return t.noInitialRun = !0, t.INITIAL_MEMORY = a.length, a;
  }
  o(he, "prepareSnapshot");
  async function we(e) {
    let t = await _createPyodideModule(e);
    if (e.exitCode !== void 0) throw new t.ExitStatus(e.exitCode);
    return t;
  }
  o(we, "createPyodideModule");
  function Ee(e, t) {
    let r = e.API;
    if (t.pyproxyToStringRepr && r.setPyProxyToStringMethod(!0), t.convertNullToNone && r.setCompatNullToNone(!0), t.toJsLiteralMap && r.setCompatToJsLiteralMap(!0), r.version !== x && t.checkAPIVersion) throw new Error(`Pyodide version does not match: '${x}' <==> '${r.version}'. If you updated the Pyodide version, make sure you also updated the 'indexURL' parameter passed to loadPyodide.`);
    e.locateFile = (a) => {
      throw a.endsWith(".so") ? new Error(`Failed to find dynamic library "${a}"`) : new Error(`Unexpected call to locateFile("${a}")`);
    };
  }
  o(Ee, "configureAPI");
  function ve(e, t, r) {
    let a = e.API, n;
    return t && (n = a.restoreSnapshot(t)), a.finalizeBootstrap(n, r._snapshotDeserializer);
  }
  o(ve, "bootstrapPyodide");
  async function be(e, t) {
    let r = e._api;
    return r.sys.path.insert(0, ""), r._pyodide.set_excepthook(), await r.packageIndexReady, r.initializeStreams(t.stdin, t.stdout, t.stderr), e;
  }
  o(be, "finalizeSetup");
  async function Ne(e = {}) {
    let t = await me(e), r = ye(t);
    await ge(t);
    let a = await he(t, r), n = await we(r);
    Ee(n, t);
    let i = ve(n, a, t);
    return await be(i, t);
  }
  o(Ne, "loadPyodide");
  let O = null;
  async function $() {
    return O || (console.log("Worker: Initializing Pyodide..."), O = await Ne({
      indexURL: "https://cdn.jsdelivr.net/pyodide/v0.26.4/full/"
    }), await O.loadPackage(["pandas", "micropip"]), console.log("Worker: Pyodide and pandas loaded."), O);
  }
  self.onmessage = async (e) => {
    const { type: t, code: r, data: a } = e.data;
    if (t === "INIT")
      try {
        await $(), self.postMessage({ type: "INIT_COMPLETE" });
      } catch (n) {
        self.postMessage({ type: "ERROR", error: n.message });
      }
    else if (t === "RUN_CODE")
      try {
        const n = await $();
        a && (n.globals.set("df_json", JSON.stringify(a)), await n.runPythonAsync(`
          import pandas as pd
          import json
          df = pd.read_json(df_json)
        `));
        const i = await n.runPythonAsync(r), s = i?.toJs ? i.toJs() : i;
        self.postMessage({ type: "RUN_COMPLETE", result: s });
      } catch (n) {
        self.postMessage({ type: "ERROR", error: n.message });
      }
  };
});
export default Te();
