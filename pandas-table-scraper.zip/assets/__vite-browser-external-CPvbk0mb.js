var e = {};
export {
  e as default
};
